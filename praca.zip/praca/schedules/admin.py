from django.contrib import admin
from schedules.models import *

admin.site.register(Schedules)
