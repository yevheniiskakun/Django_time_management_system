from django.contrib import admin
from employees.models import *

admin.site.register(Employee)
