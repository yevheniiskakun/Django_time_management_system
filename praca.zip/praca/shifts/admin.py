from django.contrib import admin
from shifts.models import *

admin.site.register(Shifts)